import http from "http";
import { totalSales } from "./totalSalesCache.js";

http
  .createServer(async (req, res) => {
    const url = new URL(req.url, "http://localhost:8080");
    const product = url.searchParams.get("product");

    console.log(`Processing query: ${url}`);

    const sum = await totalSales(product);

    res.setHeader("Content-Type", "application/json");
    res.writeHead(200);
    res.end(
      JSON.stringify({
        sum,
        product,
      })
    );
  })
  .listen(8080, () => {
    console.log("Listening on port 8080");
  });

//   https://github.com/PacktPublishing/Node.js-Design-Patterns-Third-Edition/tree/master/11-advanced-recipes/04-batching-and-caching

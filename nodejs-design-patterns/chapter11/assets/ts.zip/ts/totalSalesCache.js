import { totalSales as totalSalesBatch } from "./totalSales.js";

const cache = new Map();
const CACHE_TTL = 30_000;

export async function totalSales(product) {
  if (cache.has(product)) {
    return cache.get(product);
  }

  const resultPromise = totalSalesBatch(product);
  cache.set(product, resultPromise);
  resultPromise
    .then(() => {
      setTimeout(() => {
        cache.delete(product);
      }, CACHE_TTL);
    })
    .catch((error) => {
      cache.delete(product);
      throw error;
    });

  return resultPromise;
}

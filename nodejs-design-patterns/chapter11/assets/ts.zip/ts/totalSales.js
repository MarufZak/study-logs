import level from "level";
import sublevel from "subleveldown";

const db = level("database");
const salesDb = sublevel(db, "sales");

export async function totalSales(product) {
  const now = Date.now();
  let sum = 0;
  for await (const transaction of salesDb.createValueStream()) {
    let objectTransaction;

    try {
      objectTransaction = JSON.parse(transaction);
    } catch (error) {
      continue;
    }

    if (!product || objectTransaction.product === product) {
      sum += objectTransaction.amount;
    }
  }

  console.log(`totalSales() took: ${Date.now() - now}ms`);

  return sum;
}

totalSales("book").then(console.log);

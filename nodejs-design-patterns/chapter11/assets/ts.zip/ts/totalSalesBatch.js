import { totalSales as totalSalesRaw } from "./totalSales.js";

const runningRequestsMap = new Map();

export async function totalSales(product) {
  if (runningRequestsMap.has(product)) {
    return runningRequestsMap.get(product);
  }

  const resultPromise = totalSalesRaw(product);
  runningRequestsMap.set(product, resultPromise);
  resultPromise.finally(() => {
    runningRequestsMap.delete(product);
  });

  return resultPromise;
}
